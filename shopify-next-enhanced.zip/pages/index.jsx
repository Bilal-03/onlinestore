import { useEffect, useState } from "react";

const mockProducts = [
  {
    id: 1,
    title: "Minimalist Cotton T-Shirt",
    description: "100% organic cotton, soft and breathable, perfect for everyday wear.",
    image: "https://via.placeholder.com/300x200?text=T-Shirt",
  },
  {
    id: 2,
    title: "ZenPods – Wireless Bluetooth Earbuds",
    description: "Crystal-clear audio, 20-hour battery life, IPX5 water resistance.",
    image: "https://via.placeholder.com/300x200?text=Earbuds",
  },
  {
    id: 3,
    title: "Shockproof iPhone 14 Case – Matte Black",
    description: "Sleek protection with raised edges and anti-slip grip.",
    image: "https://via.placeholder.com/300x200?text=iPhone+Case",
  },
];

export default function Home() {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    setProducts(mockProducts);
  }, []);

  return (
    <div className="font-sans bg-gray-50 text-gray-900">
      <header className="bg-white shadow sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold text-blue-600">Bilal's Store</h1>
          <nav className="space-x-6">
            <a href="#" className="hover:text-blue-500">Home</a>
            <a href="#" className="hover:text-blue-500">Products</a>
            <a href="#" className="hover:text-blue-500">Contact</a>
          </nav>
        </div>
      </header>

      <section className="bg-gradient-to-r from-blue-100 to-indigo-100 py-16 px-6 text-center">
        <h2 className="text-4xl font-extrabold mb-4">Discover Amazing Products</h2>
        <p className="text-lg mb-6">Explore a curated collection just for you</p>
        <button className="bg-blue-600 text-white px-6 py-3 rounded-full shadow hover:bg-blue-700 transition">Shop Now</button>
      </section>

      <main className="max-w-7xl mx-auto px-4 py-10">
        <h3 className="text-2xl font-semibold mb-6">Our Products</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {products.map(product => (
            <div key={product.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:scale-105 transform transition duration-300">
              <img src={product.image} alt={product.title} className="w-full h-56 object-cover" />
              <div className="p-4">
                <h4 className="text-lg font-bold">{product.title}</h4>
                <p className="text-sm text-gray-600">{product.description}</p>
              </div>
            </div>
          ))}
        </div>
      </main>

      <footer className="bg-white border-t py-6 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Bilal's Store. All rights reserved.
      </footer>
    </div>
  );
}
